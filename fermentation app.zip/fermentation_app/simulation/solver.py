"""
Bioreactor ODE systems for batch and fed-batch modes.

State vector: [X, S, P, V]
    X  – Biomass concentration   (g/L)
    S  – Substrate concentration (g/L)
    P  – Product concentration   (g/L)
    V  – Liquid volume           (L)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, List, Tuple

import numpy as np
from scipy.integrate import solve_ivp

from models.kinetics import luedeking_piret


@dataclass
class ReactorParams:
    # Stoichiometry
    Yxs: float = 0.5          # Biomass yield on substrate  (g X / g S)
    Yps: float = 0.3          # Product yield on substrate  (g P / g S)

    # Luedeking-Piret
    alpha: float = 0.8        # Growth-associated product coefficient
    beta:  float = 0.05       # Non-growth-associated coefficient

    # Fed-batch feed
    F:    float = 0.0         # Feed flow rate  (L/h)  — 0 → batch
    Sf:   float = 50.0        # Feed substrate concentration (g/L)

    # Initial conditions
    X0: float = 0.1           # Initial biomass    (g/L)
    S0: float = 10.0          # Initial substrate  (g/L)
    P0: float = 0.0           # Initial product    (g/L)
    V0: float = 1.0           # Initial volume     (L)

    # Simulation
    t_end: float = 24.0       # Total run time (h)
    n_points: int = 500


def make_ode(mu_func: Callable, params: ReactorParams) -> Callable:
    """
    Build the ODE RHS function for the given growth-rate callable and reactor params.
    """
    def ode(t: float, y: List[float]) -> List[float]:
        X, S, P, V = y
        X = max(X, 0.0)
        S = max(S, 0.0)
        P = max(P, 0.0)
        V = max(V, 1e-9)

        mu   = mu_func(S)
        qp   = luedeking_piret(mu, X, params.alpha, params.beta)
        D    = params.F / V          # dilution rate

        dX = (mu - D) * X
        dS = -mu * X / params.Yxs + D * (params.Sf - S)
        dP = qp - D * P
        dV = params.F

        return [dX, dS, dP, dV]

    return ode


def run_simulation(
    mu_func: Callable,
    params: ReactorParams,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Integrate the bioreactor ODEs.

    Returns
    -------
    t, X, S, P, V  – all as 1-D numpy arrays
    """
    y0   = [params.X0, params.S0, params.P0, params.V0]
    t_span = (0.0, params.t_end)
    t_eval = np.linspace(0.0, params.t_end, params.n_points)

    sol = solve_ivp(
        make_ode(mu_func, params),
        t_span,
        y0,
        method="LSODA",
        t_eval=t_eval,
        rtol=1e-6,
        atol=1e-9,
        dense_output=False,
    )

    if not sol.success:
        raise RuntimeError(f"ODE solver failed: {sol.message}")

    t = sol.t
    X, S, P, V = sol.y
    return t, X, S, P, V
