"""
Precision Fermentation — Mechanistic Model Builder
Phase 1: Simulator core with Streamlit UI
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

from models.kinetics import KINETIC_MODELS, KINETIC_PARAMS, PARAM_DEFAULTS, PARAM_RANGES, PARAM_UNITS
from simulation.solver import ReactorParams, run_simulation

# ─── Page config ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="FermentOS · Model Builder",
    page_icon="🧫",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500;600&display=swap');

:root {
    --bg:       #0d1117;
    --surface:  #161b22;
    --border:   #21262d;
    --accent:   #00e5a0;
    --accent2:  #0ea5e9;
    --accent3:  #f97316;
    --text:     #e6edf3;
    --muted:    #7d8590;
}

html, body, [data-testid="stAppViewContainer"] {
    background-color: var(--bg) !important;
    color: var(--text) !important;
    font-family: 'DM Sans', sans-serif;
}

[data-testid="stSidebar"] {
    background-color: var(--surface) !important;
    border-right: 1px solid var(--border);
}

[data-testid="stSidebar"] * { color: var(--text) !important; }

h1, h2, h3 { font-family: 'Space Mono', monospace !important; }

h1 {
    font-size: 1.6rem !important;
    color: var(--accent) !important;
    letter-spacing: -0.03em;
    margin-bottom: 0 !important;
}

.subtitle {
    color: var(--muted);
    font-size: 0.85rem;
    font-family: 'Space Mono', monospace;
    margin-bottom: 1.5rem;
    letter-spacing: 0.05em;
}

.metric-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1rem 1.2rem;
    margin-bottom: 0.5rem;
}

.metric-value {
    font-family: 'Space Mono', monospace;
    font-size: 1.6rem;
    font-weight: 700;
    color: var(--accent);
}

.metric-label {
    color: var(--muted);
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}

.metric-unit {
    color: var(--muted);
    font-size: 0.8rem;
    font-family: 'Space Mono', monospace;
}

.section-header {
    font-family: 'Space Mono', monospace;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    color: var(--muted);
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.4rem;
    margin: 1.2rem 0 0.8rem 0;
}

.badge {
    display: inline-block;
    background: rgba(0,229,160,0.12);
    color: var(--accent);
    border: 1px solid rgba(0,229,160,0.3);
    border-radius: 4px;
    padding: 0.15rem 0.5rem;
    font-size: 0.7rem;
    font-family: 'Space Mono', monospace;
    letter-spacing: 0.05em;
}

/* Streamlit widget overrides */
.stSlider > div > div > div > div { background: var(--accent) !important; }
.stSelectbox > div > div { background: var(--surface) !important; border-color: var(--border) !important; }
.stNumberInput > div > div > input { background: var(--surface) !important; border-color: var(--border) !important; color: var(--text) !important; }
[data-testid="stMetricValue"] { color: var(--accent) !important; font-family: 'Space Mono', monospace !important; }
.stDownloadButton > button { background: var(--accent) !important; color: #000 !important; border: none !important; font-weight: 600 !important; }
</style>
""", unsafe_allow_html=True)


# ─── Header ──────────────────────────────────────────────────────────────────
col_title, col_badge = st.columns([5, 1])
with col_title:
    st.markdown("# 🧫 FermentOS")
    st.markdown('<p class="subtitle">MECHANISTIC MODEL BUILDER · PHASE 1 · PRECISION FERMENTATION</p>', unsafe_allow_html=True)
with col_badge:
    st.markdown('<br><span class="badge">● SIMULATOR</span>', unsafe_allow_html=True)

st.markdown("---")

# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙ Model Configuration")

    # ── Kinetics ─────────────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Growth Kinetics</p>', unsafe_allow_html=True)
    kinetic_model = st.selectbox("Kinetic Model", list(KINETIC_MODELS.keys()))
    kinetic_params_needed = KINETIC_PARAMS[kinetic_model]

    kinetic_values = {}
    for p in kinetic_params_needed:
        lo, hi = PARAM_RANGES[p]
        unit   = PARAM_UNITS.get(p, "")
        label  = f"{p}  [{unit}]" if unit != "—" else p
        kinetic_values[p] = st.slider(
            label,
            min_value=float(lo),
            max_value=float(hi),
            value=float(PARAM_DEFAULTS[p]),
            step=float((hi - lo) / 200),
            format="%.4f",
        )

    # ── Reactor Mode ─────────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Reactor Mode</p>', unsafe_allow_html=True)
    reactor_mode = st.selectbox("Mode", ["Batch", "Fed-Batch"])
    feed_rate = 0.0
    feed_conc = 50.0
    if reactor_mode == "Fed-Batch":
        feed_rate = st.slider("Feed rate F  [L/h]", 0.0, 1.0, 0.05, 0.005, format="%.3f")
        feed_conc = st.slider("Feed conc Sf  [g/L]", 1.0, 200.0, 50.0, 1.0)

    # ── Stoichiometry ─────────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Stoichiometry</p>', unsafe_allow_html=True)
    Yxs   = st.slider("Yxs  [g X/g S]", 0.05, 1.0,  0.50, 0.01)
    alpha = st.slider("α  (growth-assoc.)", 0.0, 5.0,  0.80, 0.05)
    beta  = st.slider("β  (non-growth-assoc.)", 0.0, 0.5, 0.05, 0.005, format="%.3f")

    # ── Initial Conditions ────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Initial Conditions</p>', unsafe_allow_html=True)
    X0 = st.number_input("X₀  [g/L]",  min_value=0.001, max_value=50.0,  value=0.1,  step=0.01)
    S0 = st.number_input("S₀  [g/L]",  min_value=0.1,   max_value=200.0, value=10.0, step=0.5)
    P0 = st.number_input("P₀  [g/L]",  min_value=0.0,   max_value=50.0,  value=0.0,  step=0.01)
    V0 = st.number_input("V₀  [L]",    min_value=0.1,   max_value=1000.0, value=1.0, step=0.1)

    # ── Run time ─────────────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Simulation</p>', unsafe_allow_html=True)
    t_end = st.slider("Run time  [h]", 1.0, 120.0, 24.0, 0.5)


# ─── Build mu function ───────────────────────────────────────────────────────
model_fn = KINETIC_MODELS[kinetic_model]

def mu_func(S):
    return model_fn(S=S, **kinetic_values)

# ─── Run simulation ──────────────────────────────────────────────────────────
params = ReactorParams(
    Yxs=Yxs, alpha=alpha, beta=beta,
    F=feed_rate, Sf=feed_conc,
    X0=X0, S0=S0, P0=P0, V0=V0,
    t_end=t_end,
)

try:
    t, X, S, P, V = run_simulation(mu_func, params)
    sim_ok = True
except Exception as e:
    st.error(f"Simulation error: {e}")
    sim_ok = False

# ─── KPIs ────────────────────────────────────────────────────────────────────
if sim_ok:
    X_max   = float(np.max(X))
    P_max   = float(np.max(P))
    S_final = float(S[-1])
    mu_max_achieved = float(np.max([mu_func(s) for s in S]))
    t_double = np.log(2) / mu_max_achieved if mu_max_achieved > 0 else float("inf")

    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.metric("Peak Biomass", f"{X_max:.2f} g/L")
    with k2:
        st.metric("Peak Product", f"{P_max:.2f} g/L")
    with k3:
        st.metric("Residual Substrate", f"{S_final:.3f} g/L")
    with k4:
        st.metric("Doubling Time", f"{t_double:.2f} h")

    st.markdown("")

    # ─── Main plot ───────────────────────────────────────────────────────────
    COLORS = {
        "X": "#00e5a0",
        "S": "#f97316",
        "P": "#0ea5e9",
        "V": "#a78bfa",
    }

    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=["Biomass  X", "Substrate  S", "Product  P", "Volume  V"],
        vertical_spacing=0.14,
        horizontal_spacing=0.10,
    )

    datasets = [
        (X, "Biomass X",    "g/L",  1, 1, COLORS["X"]),
        (S, "Substrate S",  "g/L",  1, 2, COLORS["S"]),
        (P, "Product P",    "g/L",  2, 1, COLORS["P"]),
        (V, "Volume V",     "L",    2, 2, COLORS["V"]),
    ]

    for y_data, name, unit, row, col, color in datasets:
        fig.add_trace(
            go.Scatter(
                x=t, y=y_data,
                name=name,
                mode="lines",
                line=dict(color=color, width=2.5),
                fill="tozeroy",
                fillcolor=color.replace("#", "rgba(") + ",0.07)" if color.startswith("#") else color,
            ),
            row=row, col=col,
        )
        fig.update_yaxes(title_text=unit, row=row, col=col,
                         gridcolor="#21262d", zerolinecolor="#21262d")
        fig.update_xaxes(title_text="Time (h)", row=row, col=col,
                         gridcolor="#21262d", zerolinecolor="#21262d")

    fig.update_layout(
        height=540,
        paper_bgcolor="#0d1117",
        plot_bgcolor="#0d1117",
        font=dict(family="DM Sans", color="#e6edf3", size=12),
        showlegend=False,
        margin=dict(t=50, b=30, l=40, r=20),
    )
    for ann in fig.layout.annotations:
        ann.font.family = "Space Mono"
        ann.font.color  = "#7d8590"
        ann.font.size   = 11

    st.plotly_chart(fig, use_container_width=True)

    # ─── Growth rate curve ───────────────────────────────────────────────────
    with st.expander("📈 Growth Rate Profile  μ(S)"):
        S_range = np.linspace(0, max(S0 * 1.5, 0.1), 400)
        mu_vals = [mu_func(s) for s in S_range]

        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(
            x=S_range, y=mu_vals,
            mode="lines",
            line=dict(color="#00e5a0", width=2.5),
            name="μ(S)",
        ))
        fig2.add_vline(x=S0, line_dash="dash", line_color="#f97316",
                       annotation_text="S₀", annotation_font_color="#f97316")
        fig2.update_layout(
            height=280,
            paper_bgcolor="#0d1117",
            plot_bgcolor="#0d1117",
            font=dict(family="DM Sans", color="#e6edf3"),
            xaxis=dict(title="Substrate S (g/L)", gridcolor="#21262d"),
            yaxis=dict(title="μ  (h⁻¹)", gridcolor="#21262d"),
            margin=dict(t=20, b=40, l=60, r=20),
        )
        st.plotly_chart(fig2, use_container_width=True)

    # ─── Data table + download ────────────────────────────────────────────────
    with st.expander("📊 Simulation Data"):
        df = pd.DataFrame({"time_h": t, "X_gL": X, "S_gL": S, "P_gL": P, "V_L": V})
        df = df.round(6)
        st.dataframe(df, use_container_width=True, height=280)

        csv = df.to_csv(index=False).encode()
        st.download_button(
            "⬇ Download CSV",
            csv,
            file_name="fermentation_simulation.csv",
            mime="text/csv",
        )

    # ─── Model equation summary ───────────────────────────────────────────────
    with st.expander("🔬 Model Equations"):
        st.markdown(f"""
**Growth kinetics**: `{kinetic_model}`
```
μ = f(S, {', '.join(f'{k}={v:.4f}' for k, v in kinetic_values.items())})
```

**Mass balances (state variables)**
```
dX/dt  =  (μ - D) · X
dS/dt  = -(μ/Yxs) · X  +  D · (Sf - S)
dP/dt  =  (α·μ + β) · X  -  D · P
dV/dt  =  F
```

**Parameters**
```
Yxs = {Yxs}   g biomass / g substrate
α   = {alpha}   g product / g biomass  (growth-associated)
β   = {beta}   g product / g biomass / h  (non-growth-associated)
F   = {feed_rate} L/h    Sf = {feed_conc} g/L
```
        """)
