"""
Modular ODE assembler.

State vector: [X, Gly, MeOH, P, DO, V]
Components are activated via ModelConfig passed from the UI composer.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
from dataclasses import dataclass

from models.kinetics import monod, andrews
from models.constraints import (
    clip_positive, enforce_substrate, enforce_do,
    enforce_product_formation, enforce_feed, apply_product_inhibition
)
from models.oxygen import do_balance


@dataclass
class ModelConfig:
    # ── Card 1: Basal Growth (always active) ─────────────────────────────────
    growth_model: str   = "Monod"
    mu_max_gly:   float = 0.40
    Ks_gly:       float = 0.10
    Ki_gly:       float = 10.0
    Yxs_gly:      float = 0.50

    # ── Card 2: Second Substrate — Methanol ───────────────────────────────────
    use_methanol:        bool  = False
    mu_max_meoh:         float = 0.10
    Ks_meoh:             float = 0.10
    Ki_meoh:             float = 3.0
    Yxs_meoh:            float = 0.30
    F_meoh:              float = 0.05
    Sf_meoh:             float = 500.0
    meoh_t_start:        float = 8.0
    meoh_t_end:          float = 48.0
    meoh_ramp:           bool  = False
    meoh_ramp_duration:  float = 2.0

    # ── Card 3: Fed-Batch Glycerol ────────────────────────────────────────────
    use_fedbatch_gly: bool  = False
    F_gly:            float = 0.10
    Sf_gly:           float = 500.0
    gly_t_start:      float = 2.0
    gly_t_end:        float = 8.0

    # ── Card 4: Product Inhibition ────────────────────────────────────────────
    use_product_inhibition: bool  = False
    Ki_product:             float = 20.0

    # ── Card 5: Product Formation ─────────────────────────────────────────────
    use_product:       bool  = False
    alpha:             float = 0.80
    beta:              float = 0.05
    meoh_only_product: bool  = False
    Gly_repression:    float = 0.5

    # ── Card 6: Dissolved Oxygen ──────────────────────────────────────────────
    use_do:    bool  = False
    kLa:       float = 100.0
    DO_sat:    float = 8.0
    DO_crit:   float = 1.0
    mut_plus:  bool  = True
    Yxo_gly:  float = 0.50
    mo_gly:   float = 0.01
    Yxo_meoh: float = 0.20
    mo_meoh:  float = 0.05

    # ── Initial Conditions ────────────────────────────────────────────────────
    X0:    float = 0.10
    Gly0:  float = 40.0
    MeOH0: float = 0.0
    P0:    float = 0.0
    DO0:   float = 7.0
    V0:    float = 1.0

    # ── Simulation ────────────────────────────────────────────────────────────
    t_end:    float = 48.0
    n_points: int   = 600


def _meoh_feed_rate(cfg: ModelConfig, t: float) -> float:
    if not cfg.use_methanol:
        return 0.0
    F = enforce_feed(cfg.F_meoh, t, cfg.meoh_t_start, cfg.meoh_t_end)
    if cfg.meoh_ramp and F > 0:
        elapsed = t - cfg.meoh_t_start
        F *= min(elapsed / max(cfg.meoh_ramp_duration, 1e-9), 1.0)
    return F


def _gly_feed_rate(cfg: ModelConfig, t: float) -> float:
    if not cfg.use_fedbatch_gly:
        return 0.0
    return enforce_feed(cfg.F_gly, t, cfg.gly_t_start, cfg.gly_t_end)


def build_ode(cfg: ModelConfig):
    def ode(t: float, y: list) -> list:
        X, Gly, MeOH, P, DO, V = y
        X    = max(X,    0.0)
        Gly  = max(Gly,  0.0)
        MeOH = max(MeOH, 0.0)
        P    = max(P,    0.0)
        DO   = max(DO,   0.0)
        V    = max(V,    1e-9)

        F_gly   = _gly_feed_rate(cfg, t)
        F_meoh  = _meoh_feed_rate(cfg, t)
        F_total = F_gly + F_meoh
        D       = F_total / V

        # Growth on glycerol
        if cfg.growth_model == "Andrews":
            mu_gly = andrews(cfg.mu_max_gly, Gly, cfg.Ks_gly, cfg.Ki_gly)
        else:
            mu_gly = monod(cfg.mu_max_gly, Gly, cfg.Ks_gly)
        mu_gly = enforce_substrate(mu_gly, Gly)

        # Growth on methanol
        mu_meoh = 0.0
        q_meoh  = 0.0
        if cfg.use_methanol:
            mu_meoh = andrews(cfg.mu_max_meoh, MeOH, cfg.Ks_meoh, cfg.Ki_meoh)
            mu_meoh = enforce_substrate(mu_meoh, MeOH)
            q_meoh  = mu_meoh / max(cfg.Yxs_meoh, 1e-9)

        mu = mu_gly + mu_meoh

        # DO enforcement
        if cfg.use_do:
            mu = enforce_do(mu, DO, cfg.DO_crit)

        # Product inhibition
        if cfg.use_product_inhibition:
            mu = apply_product_inhibition(mu, P, cfg.Ki_product)

        # Product formation
        qp = 0.0
        if cfg.use_product:
            qp = cfg.alpha * mu * X + cfg.beta * X
            qp = enforce_product_formation(
                qp,
                MeOH=MeOH, Gly=Gly,
                meoh_only=cfg.meoh_only_product,
                Gly_rep=cfg.Gly_repression if cfg.meoh_only_product else None,
            )

        # Mass balances
        dX    = (mu - D) * X
        dGly  = (-mu_gly / max(cfg.Yxs_gly, 1e-9)) * X \
                + F_gly / V * (cfg.Sf_gly - Gly) \
                - F_meoh / V * Gly
        dMeOH = 0.0
        if cfg.use_methanol:
            dMeOH = (-mu_meoh / max(cfg.Yxs_meoh, 1e-9)) * X \
                    + F_meoh / V * (cfg.Sf_meoh - MeOH) \
                    - F_gly / V * MeOH
        dP    = (qp - D * P) if cfg.use_product else 0.0
        dDO   = 0.0
        if cfg.use_do:
            dDO = do_balance(
                kLa=cfg.kLa, DO_sat=cfg.DO_sat, DO=DO,
                mu=mu, X=X,
                on_glycerol=(Gly > 1e-6),
                on_methanol=(cfg.use_methanol and MeOH > 1e-6),
                q_meoh=q_meoh, mut_plus=cfg.mut_plus, D=D,
                Yxo_gly=cfg.Yxo_gly, mo_gly=cfg.mo_gly,
                Yxo_meoh=cfg.Yxo_meoh, mo_meoh=cfg.mo_meoh,
            )
        dV = F_total

        return [dX, dGly, dMeOH, dP, dDO, dV]

    return ode


def run_simulation(config: ModelConfig) -> dict:
    y0 = [config.X0, config.Gly0, config.MeOH0,
          config.P0, config.DO0, config.V0]
    t_span = (0.0, config.t_end)
    t_eval = np.linspace(0.0, config.t_end, config.n_points)

    sol = solve_ivp(
        build_ode(config), t_span, y0,
        method="LSODA", t_eval=t_eval,
        rtol=1e-6, atol=1e-9,
    )

    if not sol.success:
        raise RuntimeError(f"Solver failed: {sol.message}")

    return {
        "t":    sol.t,
        "X":    sol.y[0],
        "Gly":  sol.y[1],
        "MeOH": sol.y[2],
        "P":    sol.y[3],
        "DO":   sol.y[4],
        "V":    sol.y[5],
    }
