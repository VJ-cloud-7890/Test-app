"""
FermentOS — Mechanistic Model Builder
Phase 1 Rebuild: Card-based composer, modular ODE, Help tab
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

from simulation.solver import ModelConfig, run_simulation

# ─── Page config ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="FermentOS",
    page_icon="🧫",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ─── CSS ─────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500;600&display=swap');
html, body, [data-testid="stAppViewContainer"] {
    background: #0d1117 !important; color: #e6edf3 !important;
    font-family: 'DM Sans', sans-serif;
}
h1 { font-family:'Space Mono',monospace!important; color:#00e5a0!important; font-size:1.5rem!important; margin-bottom:0!important; }
h2,h3 { font-family:'Space Mono',monospace!important; color:#e6edf3!important; }
.subtitle { color:#7d8590; font-size:0.8rem; font-family:'Space Mono',monospace; letter-spacing:.06em; margin-bottom:1rem; }
.card {
    background:#161b22; border:1px solid #21262d; border-radius:10px;
    padding:1.2rem 1.4rem; margin-bottom:1rem;
}
.card-locked { border-left:3px solid #00e5a0; }
.card-active { border-left:3px solid #0ea5e9; }
.card-inactive { border-left:3px solid #21262d; opacity:0.6; }
.card-title {
    font-family:'Space Mono',monospace; font-size:0.85rem;
    font-weight:700; letter-spacing:.04em; margin-bottom:.15rem;
}
.card-tip { color:#7d8590; font-size:0.75rem; margin-bottom:.8rem; }
.badge-locked { background:rgba(0,229,160,.12); color:#00e5a0; border:1px solid rgba(0,229,160,.3); border-radius:4px; padding:.1rem .4rem; font-size:.65rem; font-family:'Space Mono',monospace; }
.badge-active { background:rgba(14,165,233,.12); color:#0ea5e9; border:1px solid rgba(14,165,233,.3); border-radius:4px; padding:.1rem .4rem; font-size:.65rem; font-family:'Space Mono',monospace; }
.help-section { background:#161b22; border:1px solid #21262d; border-radius:8px; padding:1.2rem 1.4rem; margin-bottom:1rem; }
.help-title { font-family:'Space Mono',monospace; color:#00e5a0; font-size:.85rem; font-weight:700; margin-bottom:.5rem; }
.eq { background:#0d1117; border-radius:6px; padding:.6rem 1rem; font-family:'Space Mono',monospace; font-size:.8rem; color:#a5f3c0; margin:.5rem 0; }
[data-testid="stMetricValue"] { color:#00e5a0!important; font-family:'Space Mono',monospace!important; }
.stDownloadButton>button { background:#00e5a0!important; color:#000!important; border:none!important; font-weight:600!important; }
</style>
""", unsafe_allow_html=True)


# ─── Header ──────────────────────────────────────────────────────────────────
st.markdown("# 🧫 FermentOS")
st.markdown('<p class="subtitle">MECHANISTIC MODEL BUILDER · PRECISION FERMENTATION</p>', unsafe_allow_html=True)

# ─── Tabs ─────────────────────────────────────────────────────────────────────
tab_composer, tab_sim, tab_help = st.tabs(["🧩 Model Composer", "📈 Simulation", "📖 Help"])


# ════════════════════════════════════════════════════════════════════════════════
# TAB 1 — MODEL COMPOSER
# ════════════════════════════════════════════════════════════════════════════════
with tab_composer:

    def num(label, value, min_val=0.0, max_val=1e6, step=0.01, fmt="%.4f", key=None):
        """Compact number input."""
        return st.number_input(label, min_value=float(min_val), max_value=float(max_val),
                               value=float(value), step=float(step), format=fmt, key=key)

    cfg = ModelConfig()

    col_left, col_right = st.columns(2, gap="large")

    # ── CARD 1: Basal Growth (locked) ─────────────────────────────────────────
    with col_left:
        st.markdown("""
        <div class="card card-locked">
          <div class="card-title">🌱 Card 1 — Basal Growth &nbsp;<span class="badge-locked">ALWAYS ON</span></div>
          <div class="card-tip">ⓘ How fast cells grow as a function of the primary substrate (glycerol).</div>
        </div>
        """, unsafe_allow_html=True)
        with st.expander("Configure growth parameters", expanded=True):
            cfg.growth_model = st.selectbox(
                "Kinetic model",
                ["Monod", "Andrews"],
                help="Monod: standard saturation. Andrews: adds substrate inhibition at high concentrations."
            )
            c1, c2 = st.columns(2)
            with c1:
                cfg.mu_max_gly = num("μ_max  [h⁻¹]", 0.40, 0.001, 2.0, 0.01, key="mu_max_gly")
                cfg.Ks_gly     = num("Ks  [g/L]",    0.10, 0.001, 10.0, 0.01, key="Ks_gly")
            with c2:
                cfg.Yxs_gly = num("Yxs  [g X/g S]", 0.50, 0.01, 1.0, 0.01, key="Yxs_gly")
                if cfg.growth_model == "Andrews":
                    cfg.Ki_gly = num("Ki  [g/L]", 10.0, 0.1, 100.0, 0.1, key="Ki_gly")

        st.markdown("---")

        # ── CARD 3: Fed-Batch Glycerol ─────────────────────────────────────────
        use_fb_gly = st.toggle("🔁 Card 3 — Fed-Batch Glycerol", value=False,
                               help="Add a glycerol feed after the batch phase is exhausted.")
        cfg.use_fedbatch_gly = use_fb_gly
        card_class = "card-active" if use_fb_gly else "card-inactive"
        st.markdown(f'<div class="card {card_class}"><div class="card-title">🔁 Fed-Batch Glycerol</div>'
                    f'<div class="card-tip">ⓘ Continuous glycerol feed to maintain growth before methanol induction.</div></div>',
                    unsafe_allow_html=True)
        if use_fb_gly:
            with st.expander("Configure glycerol feed", expanded=True):
                c1, c2 = st.columns(2)
                with c1:
                    cfg.F_gly   = num("Feed rate F  [L/h]", 0.10, 0.0, 10.0, 0.01, key="F_gly")
                    cfg.Sf_gly  = num("Feed conc Sf  [g/L]", 500.0, 1.0, 800.0, 10.0, key="Sf_gly")
                with c2:
                    cfg.gly_t_start = num("Start time  [h]", 2.0, 0.0, 200.0, 0.5, key="gly_t_start")
                    cfg.gly_t_end   = num("End time  [h]",   8.0, 0.0, 200.0, 0.5, key="gly_t_end")

        st.markdown("---")

        # ── CARD 5: Product Formation ──────────────────────────────────────────
        use_prod = st.toggle("🧪 Card 5 — Product Formation", value=False,
                             help="Model product accumulation using Luedeking-Piret kinetics.")
        cfg.use_product = use_prod
        card_class = "card-active" if use_prod else "card-inactive"
        st.markdown(f'<div class="card {card_class}"><div class="card-title">🧪 Product Formation</div>'
                    f'<div class="card-tip">ⓘ Luedeking-Piret: product forms proportional to growth (α) and biomass (β). '
                    f'Product will NOT form if there is no active substrate.</div></div>',
                    unsafe_allow_html=True)
        if use_prod:
            with st.expander("Configure product formation", expanded=True):
                c1, c2 = st.columns(2)
                with c1:
                    cfg.alpha = num("α  (growth-assoc.)", 0.80, 0.0, 10.0, 0.05, key="alpha")
                    cfg.beta  = num("β  (non-growth-assoc.)  [h⁻¹]", 0.05, 0.0, 1.0, 0.005, key="beta")
                with c2:
                    cfg.meoh_only_product = st.checkbox(
                        "Methanol-induced only",
                        value=False,
                        help="Product forms ONLY when methanol is present (e.g. AOX-driven expression)."
                    )
                    if cfg.meoh_only_product:
                        cfg.Gly_repression = num("Gly repression threshold  [g/L]",
                                                  0.5, 0.0, 10.0, 0.1, key="Gly_rep")

    # ── RIGHT COLUMN ──────────────────────────────────────────────────────────
    with col_right:

        # ── CARD 2: Methanol ───────────────────────────────────────────────────
        use_meoh = st.toggle("🔬 Card 2 — Second Substrate (Methanol)", value=False,
                             help="Add methanol as a second carbon source for induction phase.")
        cfg.use_methanol = use_meoh
        card_class = "card-active" if use_meoh else "card-inactive"
        st.markdown(f'<div class="card {card_class}"><div class="card-title">🔬 Methanol (Second Substrate)</div>'
                    f'<div class="card-tip">ⓘ Methanol drives AOX expression. Uses Andrews kinetics by default '
                    f'(inhibitory at high concentrations). Feed is time-scheduled.</div></div>',
                    unsafe_allow_html=True)
        if use_meoh:
            with st.expander("Configure methanol kinetics & feed", expanded=True):
                st.markdown("**Kinetics**")
                c1, c2 = st.columns(2)
                with c1:
                    cfg.mu_max_meoh = num("μ_max_MeOH  [h⁻¹]", 0.10, 0.001, 1.0, 0.005, key="mu_max_meoh")
                    cfg.Ks_meoh     = num("Ks_MeOH  [g/L]",    0.10, 0.001, 5.0, 0.01,  key="Ks_meoh")
                with c2:
                    cfg.Ki_meoh   = num("Ki_MeOH  [g/L]",      3.0,  0.1, 50.0, 0.1, key="Ki_meoh")
                    cfg.Yxs_meoh  = num("Yxs_MeOH  [g X/g S]", 0.30, 0.01, 1.0, 0.01, key="Yxs_meoh")

                st.markdown("**Feed schedule**")
                c1, c2 = st.columns(2)
                with c1:
                    cfg.F_meoh       = num("Feed rate F  [L/h]",  0.05, 0.0, 5.0,   0.005, key="F_meoh")
                    cfg.Sf_meoh      = num("Feed conc Sf  [g/L]", 500.0, 1.0, 800.0, 10.0, key="Sf_meoh")
                    cfg.meoh_t_start = num("Start time  [h]",     8.0,  0.0, 200.0, 0.5,  key="meoh_t_start")
                    cfg.meoh_t_end   = num("End time  [h]",       48.0, 0.0, 200.0, 0.5,  key="meoh_t_end")
                with c2:
                    cfg.meoh_ramp = st.checkbox("Ramp feed (linear)", value=False,
                                                help="F(t) = F_start + slope x elapsed time, capped at F_max.")
                    if cfg.meoh_ramp:
                        cfg.F_meoh_start = num("F_start  [L/h]", 0.0,  0.0, 10.0, 0.0001, fmt="%.4f", key="F_meoh_start")
                        cfg.meoh_slope   = num("Slope  [L/h/h]", 0.05, 0.0, 10.0, 0.0001, fmt="%.4f", key="meoh_slope")
                        cfg.F_meoh_max   = num("F_max  [L/h]",   0.5,  0.0, 10.0, 0.01,             key="F_meoh_max")

        st.markdown("---")

        # ── CARD 4: Product Inhibition ─────────────────────────────────────────
        use_pi = st.toggle("🚫 Card 4 — Product Inhibition", value=False,
                           help="High product concentrations slow down growth.")
        cfg.use_product_inhibition = use_pi
        card_class = "card-active" if use_pi else "card-inactive"
        st.markdown(f'<div class="card {card_class}"><div class="card-title">🚫 Product Inhibition</div>'
                    f'<div class="card-tip">ⓘ As product accumulates, it feeds back to reduce growth rate. '
                    f'Common when product is toxic at high titres.</div></div>',
                    unsafe_allow_html=True)
        if use_pi:
            with st.expander("Configure product inhibition", expanded=True):
                cfg.Ki_product = num("Ki_product  [g/L]", 20.0, 0.1, 200.0, 1.0, key="Ki_prod")

        st.markdown("---")

        # ── CARD 6: Dissolved Oxygen ───────────────────────────────────────────
        use_do = st.toggle("💨 Card 6 — Dissolved Oxygen", value=False,
                           help="Track DO as a state variable. Growth stops below DO_crit.")
        cfg.use_do = use_do
        card_class = "card-active" if use_do else "card-inactive"
        st.markdown(f'<div class="card {card_class}"><div class="card-title">💨 Dissolved Oxygen</div>'
                    f'<div class="card-tip">ⓘ OTR - OUR balance. Methanol metabolism (especially Mut+) '
                    f'causes high oxygen demand and can crash DO.</div></div>',
                    unsafe_allow_html=True)
        if use_do:
            with st.expander("Configure oxygen parameters", expanded=True):
                c1, c2 = st.columns(2)
                with c1:
                    cfg.kLa     = num("kLa  [h⁻¹]",         100.0, 1.0, 1000.0, 5.0,  key="kLa")
                    cfg.DO_sat  = num("DO_sat  [mg/L]",       8.0,  1.0,   20.0, 0.1,  key="DO_sat")
                    cfg.DO_crit = num("DO_crit  [mg/L]",      1.0,  0.0,    5.0, 0.1,  key="DO_crit")
                with c2:
                    cfg.mut_plus  = st.checkbox("Mut+ strain", value=True,
                                                help="Mut+ has much higher OUR on methanol than MutS.")
                    cfg.Yxo_gly  = num("Yxo_gly",  0.50, 0.01, 2.0, 0.01, key="Yxo_gly")
                    cfg.Yxo_meoh = num("Yxo_meoh", 0.20, 0.01, 2.0, 0.01, key="Yxo_meoh")

    # ── Initial Conditions & Run time ─────────────────────────────────────────
    st.markdown("---")
    st.markdown("### ⚗ Initial Conditions & Run Time")
    c1, c2, c3, c4, c5, c6, c7 = st.columns(7)
    with c1: cfg.X0    = num("X₀  [g/L]",   0.10, 0.001, 100.0, 0.01,  key="X0")
    with c2: cfg.Gly0  = num("Gly₀  [g/L]", 40.0, 0.0,   500.0, 1.0,   key="Gly0")
    with c3: cfg.MeOH0 = num("MeOH₀  [g/L]", 0.0, 0.0,   100.0, 0.1,   key="MeOH0")
    with c4: cfg.P0    = num("P₀  [g/L]",    0.0, 0.0,    50.0, 0.01,  key="P0")
    with c5: cfg.DO0   = num("DO₀  [mg/L]",  7.0, 0.0,    20.0, 0.1,   key="DO0")
    with c6: cfg.V0    = num("V₀  [L]",      1.0, 0.01, 5000.0, 0.1,   key="V0")
    with c7: cfg.t_end = num("Run time  [h]", 48.0, 1.0, 500.0, 1.0,   key="t_end")

    st.session_state["cfg"] = cfg


# ════════════════════════════════════════════════════════════════════════════════
# TAB 2 — SIMULATION
# ════════════════════════════════════════════════════════════════════════════════
with tab_sim:
    cfg = st.session_state.get("cfg", ModelConfig())

    if st.button("▶ Run Simulation", type="primary", use_container_width=True):
        try:
            with st.spinner("Integrating ODEs..."):
                results = run_simulation(cfg)
            st.session_state["results"] = results
        except Exception as e:
            st.error(f"Simulation error: {e}")

    results = st.session_state.get("results", None)

    if results:
        t    = results["t"]
        X    = results["X"]
        Gly  = results["Gly"]
        MeOH = results["MeOH"]
        P    = results["P"]
        DO   = results["DO"]
        V    = results["V"]

        # KPIs
        k1, k2, k3, k4, k5 = st.columns(5)
        k1.metric("Peak Biomass",   f"{np.max(X):.2f} g/L")
        k2.metric("Peak Product",   f"{np.max(P):.2f} g/L" if cfg.use_product else "—")
        k3.metric("Gly remaining",  f"{Gly[-1]:.3f} g/L")
        k4.metric("Min DO",         f"{np.min(DO):.2f} mg/L" if cfg.use_do else "—")
        k5.metric("Final Volume",   f"{V[-1]:.2f} L")

        st.markdown("")

        # Determine active plots
        plot_vars = [("Biomass X", X, "#00e5a0", "g/L")]
        plot_vars.append(("Glycerol", Gly, "#f97316", "g/L"))
        if cfg.use_methanol:
            plot_vars.append(("Methanol", MeOH, "#a78bfa", "g/L"))
        if cfg.use_product:
            plot_vars.append(("Product P", P, "#0ea5e9", "g/L"))
        if cfg.use_do:
            plot_vars.append(("DO", DO, "#f43f5e", "mg/L"))
        plot_vars.append(("Volume V", V, "#94a3b8", "L"))

        n = len(plot_vars)
        cols_per_row = 3
        rows = (n + cols_per_row - 1) // cols_per_row

        fig = make_subplots(
            rows=rows, cols=cols_per_row,
            subplot_titles=[v[0] for v in plot_vars],
            vertical_spacing=0.14,
            horizontal_spacing=0.08,
        )

        for i, (name, ydata, color, unit) in enumerate(plot_vars):
            row = i // cols_per_row + 1
            col = i % cols_per_row + 1
            r, g, b = int(color[1:3],16), int(color[3:5],16), int(color[5:7],16)
            fig.add_trace(go.Scatter(
                x=t, y=ydata, name=name, mode="lines",
                line=dict(color=color, width=2.5),
                fill="tozeroy",
                fillcolor=f"rgba({r},{g},{b},0.07)",
            ), row=row, col=col)
            fig.update_yaxes(title_text=unit, row=row, col=col,
                             gridcolor="#21262d", zerolinecolor="#21262d")
            fig.update_xaxes(title_text="Time (h)", row=row, col=col,
                             gridcolor="#21262d", zerolinecolor="#21262d")

        fig.update_layout(
            height=280 * rows,
            paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
            font=dict(family="DM Sans", color="#e6edf3", size=12),
            showlegend=False,
            margin=dict(t=50, b=30, l=40, r=20),
        )
        for ann in fig.layout.annotations:
            ann.font.update(family="Space Mono", color="#7d8590", size=11)

        st.plotly_chart(fig, use_container_width=True)

        # Active model equations summary
        with st.expander("🔬 Active Model Equations"):
            eq_lines = []
            eq_lines.append("**dX/dt** = (μ - D) · X")
            eq_lines.append("**dGly/dt** = -(μ_gly/Yxs_gly)·X + F_gly/V·(Sf_gly - Gly)")
            if cfg.use_methanol:
                eq_lines.append("**dMeOH/dt** = -(μ_meoh/Yxs_meoh)·X + F_meoh/V·(Sf_meoh - MeOH)")
                eq_lines.append("**μ** = μ_gly (Monod/Andrews on Gly) + μ_meoh (Andrews on MeOH)")
            else:
                eq_lines.append(f"**μ** = μ_gly via {cfg.growth_model} on glycerol")
            if cfg.use_product:
                eq_lines.append("**dP/dt** = (α·μ + β)·X - D·P" +
                                 (" — zero if no MeOH" if cfg.meoh_only_product else ""))
            if cfg.use_do:
                eq_lines.append("**dDO/dt** = kLa·(DO_sat - DO) - OUR - D·DO")
            if cfg.use_product_inhibition:
                eq_lines.append("**Product inhibition**: μ × (1 - P/Ki_product)")
            for line in eq_lines:
                st.markdown(f"- {line}")

        # Data table + download
        with st.expander("📊 Simulation Data"):
            df = pd.DataFrame({"time_h": t, "X_gL": X, "Gly_gL": Gly,
                                "MeOH_gL": MeOH, "P_gL": P, "DO_mgL": DO, "V_L": V})
            st.dataframe(df.round(5), use_container_width=True, height=250)
            st.download_button("⬇ Download CSV", df.to_csv(index=False).encode(),
                               "fermentation_results.csv", "text/csv")
    else:
        st.info("Configure your model in the **Model Composer** tab, then click **Run Simulation**.")


# ════════════════════════════════════════════════════════════════════════════════
# TAB 3 — HELP
# ════════════════════════════════════════════════════════════════════════════════
with tab_help:
    st.markdown("## 📖 Help & Reference")
    st.markdown("Explanations of every model component, equations, and guidance for Pichia fermentation.")

    # ── Model Components ──────────────────────────────────────────────────────
    st.markdown("### 🧩 Model Components")

    with st.expander("🌱 Card 1 — Basal Growth (Monod / Andrews)"):
        st.markdown("""
<div class="help-section">
<div class="help-title">What it is</div>
Describes how fast cells grow as a function of substrate (glycerol) concentration.
Always included — you cannot have a fermentation model without a growth term.

<div class="help-title">Monod kinetics</div>
The standard model. Growth increases with substrate and saturates at high concentrations.
<div class="eq">μ = μ_max · S / (Ks + S)</div>

- **μ_max** — maximum specific growth rate [h⁻¹]. For Pichia on glycerol, typically 0.2–0.5 h⁻¹
- **Ks** — half-saturation constant [g/L]. Substrate at which μ = μ_max/2. Typically 0.05–0.2 g/L for glycerol

<div class="help-title">Andrews kinetics (substrate inhibition)</div>
At high substrate concentrations, growth actually slows down. Substrate acts as an inhibitor.
<div class="eq">μ = μ_max · S / (Ks + S + S²/Ki)</div>

- **Ki** — inhibition constant [g/L]. Higher Ki = inhibition kicks in later. Relevant for methanol.

<div class="help-title">When to use Andrews</div>
Methanol in Pichia — too much methanol is toxic. For glycerol, Monod is usually sufficient unless you are running very high glycerol concentrations.
</div>
""", unsafe_allow_html=True)

    with st.expander("🔬 Card 2 — Second Substrate (Methanol)"):
        st.markdown("""
<div class="help-section">
<div class="help-title">What it is</div>
Adds methanol as a second carbon source. In Pichia, methanol induces the AOX promoter which drives recombinant protein expression.

<div class="help-title">Growth on methanol (Andrews by default)</div>
<div class="eq">μ_meoh = μ_max_meoh · MeOH / (Ks_meoh + MeOH + MeOH²/Ki_meoh)</div>

Andrews is used by default because methanol is inhibitory at high concentrations.

<div class="help-title">Total growth rate</div>
<div class="eq">μ_total = μ_glycerol + μ_methanol</div>

<div class="help-title">Pichia-specific notes</div>

- **Mut+** strains metabolise methanol rapidly → high OUR, higher μ_max on MeOH
- **MutS** strains metabolise methanol slowly → low OUR, lower μ_max on MeOH
- Typical Ki_MeOH: 2–5 g/L for MutS, slightly higher for Mut+
- Methanol feed usually starts after glycerol is depleted or during taper

<div class="help-title">Feed schedule</div>
You set a start time, end time, and feed rate. Optional ramp linearly increases feed rate from zero to avoid methanol accumulation shock.
</div>
""", unsafe_allow_html=True)

    with st.expander("🔁 Card 3 — Fed-Batch Glycerol"):
        st.markdown("""
<div class="help-section">
<div class="help-title">What it is</div>
After the initial batch glycerol is consumed, a pump adds more glycerol to keep cells growing at high density before methanol induction.

<div class="help-title">Mass balance with feed</div>
<div class="eq">dGly/dt = -(μ_gly/Yxs)·X + F_gly/V·(Sf_gly - Gly)</div>

- **F_gly** — feed flow rate [L/h]
- **Sf_gly** — feed substrate concentration [g/L]. Typically 500–600 g/L for glycerol feeds
- **t_start / t_end** — when the pump is active

<div class="help-title">Pichia fed-batch notes</div>
Typical fed-batch glycerol phase lasts 4–12 hours, targeting a specific growth rate (μ_set) by controlling feed rate. High feed → glycerol accumulates → possible overflow metabolism.
</div>
""", unsafe_allow_html=True)

    with st.expander("🚫 Card 4 — Product Inhibition"):
        st.markdown("""
<div class="help-section">
<div class="help-title">What it is</div>
As product accumulates, it feeds back to inhibit growth. Common when a product is toxic to cells at high concentrations.

<div class="help-title">Equation</div>
<div class="eq">μ_effective = μ · (1 - P/Ki_product)</div>

- **Ki_product** — concentration at which growth is completely inhibited [g/L]
- If P > Ki_product, growth is set to zero

<div class="help-title">When to use</div>
Secreted proteins at very high titres, or when you observe growth decline correlated with product accumulation rather than substrate depletion.
</div>
""", unsafe_allow_html=True)

    with st.expander("🧪 Card 5 — Product Formation"):
        st.markdown("""
<div class="help-section">
<div class="help-title">What it is</div>
Models how product accumulates over time. Uses the Luedeking-Piret framework — product forms both during growth and independently of growth.

<div class="help-title">Equation</div>
<div class="eq">dP/dt = (α·μ + β)·X - D·P</div>

- **α** — growth-associated coefficient [g P / g X]. Product forms proportional to growth rate
- **β** — non-growth-associated coefficient [g P / g X / h]. Product forms even when cells are not growing (maintenance production)
- **D·P** — dilution term (fed-batch only)

<div class="help-title">Constraints enforced automatically</div>

- Product is zero if there is no substrate (no feed = no production)
- If "Methanol-induced only" is checked: product is zero unless MeOH > 0.01 g/L
- If glycerol repression is set: product is suppressed when Gly > threshold (AOX repression)
- Product cannot go negative

<div class="help-title">Pichia notes</div>
AOX-driven expression means α and β are both significant during methanol phase. During glycerol phase, both are typically near zero (set meoh_only = True).
</div>
""", unsafe_allow_html=True)

    with st.expander("💨 Card 6 — Dissolved Oxygen"):
        st.markdown("""
<div class="help-section">
<div class="help-title">What it is</div>
Tracks dissolved oxygen as a state variable. Growth stops if DO falls below the critical threshold (DO_crit).

<div class="help-title">Equation</div>
<div class="eq">dDO/dt = OTR - OUR - D·DO</div>
<div class="eq">OTR = kLa · (DO_sat - DO)</div>
<div class="eq">OUR = (μ/Yxo + mo) · X</div>

- **kLa** — volumetric oxygen transfer coefficient [h⁻¹]. Depends on agitation, aeration, vessel geometry
- **DO_sat** — oxygen saturation [mg/L]. ~8 mg/L in water at 30°C, 1 atm air
- **DO_crit** — minimum DO below which growth stops [mg/L]
- **Yxo** — biomass yield on oxygen [g X / g O2]
- **mo** — maintenance oxygen demand [g O2 / g X / h]

<div class="help-title">Mut+ vs MutS oxygen demand</div>

**Mut+**: AOX pathway fully active, methanol oxidised rapidly → very high OUR during methanol phase. kLa must be high or DO will crash.

**MutS**: Methanol metabolised slowly → low OUR, DO easier to maintain.

<div class="help-title">Practical implication</div>
During methanol induction in Mut+, DO can drop sharply. This is a common process bottleneck. The model will show this behaviour and you can tune kLa or feed rate accordingly.
</div>
""", unsafe_allow_html=True)

    # ── Glossary ──────────────────────────────────────────────────────────────
    st.markdown("### 📚 Glossary")
    with st.expander("Parameter definitions"):
        st.markdown("""
| Symbol | Name | Units | Meaning |
|--------|------|-------|---------|
| μ | Specific growth rate | h⁻¹ | How fast cells multiply per unit time |
| μ_max | Maximum growth rate | h⁻¹ | Growth rate when substrate is not limiting |
| Ks | Half-saturation constant | g/L | Substrate conc where μ = μ_max/2 |
| Ki | Inhibition constant | g/L | Substrate/product conc where inhibition is significant |
| Yxs | Biomass yield on substrate | g X/g S | How much biomass per gram of substrate consumed |
| α | Growth-associated product coeff | g P/g X | Product formed per unit biomass growth |
| β | Non-growth-associated coeff | g P/g X/h | Product formed independently of growth |
| kLa | Oxygen transfer coefficient | h⁻¹ | How fast O2 transfers from gas to liquid |
| OTR | Oxygen transfer rate | g/L/h | Rate of O2 entering the liquid |
| OUR | Oxygen uptake rate | g/L/h | Rate of O2 consumed by cells |
| DO | Dissolved oxygen | mg/L | O2 concentration in liquid |
| D | Dilution rate | h⁻¹ | F/V — how fast liquid is exchanged |
| F | Feed flow rate | L/h | Volumetric feed pump rate |
| Sf | Feed concentration | g/L | Substrate concentration in feed reservoir |
""")

    # ── Pichia Quick Reference ────────────────────────────────────────────────
    st.markdown("### 🧬 Pichia Fermentation Quick Reference")
    with st.expander("Typical parameter ranges"):
        st.markdown("""
| Parameter | Glycerol phase | Methanol phase |
|-----------|---------------|----------------|
| μ_max | 0.2–0.5 h⁻¹ | 0.02–0.12 h⁻¹ |
| Ks | 0.05–0.2 g/L | 0.05–0.15 g/L |
| Ki_MeOH | — | 2–8 g/L |
| Yxs | 0.4–0.6 g/g | 0.15–0.35 g/g |
| kLa (typical) | 100–400 h⁻¹ | 200–600 h⁻¹ |
| DO_crit | 10–20% sat | 10–20% sat |
| Gly feed Sf | 500–600 g/L | — |
| MeOH feed Sf | — | 100–500 g/L |

**Process phases (typical 5L bioreactor)**
1. Batch glycerol: 0–12 h, ~40 g/L glycerol, reach OD ~20
2. Fed-batch glycerol: 12–20 h, exponential or constant feed
3. Glycerol taper + methanol bolus: 20–24 h, transition phase
4. Methanol induction: 24–72+ h, product accumulates
""")

    st.markdown("### ❓ FAQ")
    with st.expander("Why is my product zero?"):
        st.markdown("""
Check:
- Is **Card 5 (Product Formation)** toggled ON?
- If 'Methanol-induced only' is checked, is **Card 2 (Methanol)** also ON and is MeOH > 0?
- Are α and β both zero? At least one should be > 0.
- Is **DO** crashing below DO_crit? If so, growth and production both stop.
""")
    with st.expander("Why does DO crash during methanol phase?"):
        st.markdown("""
This is physically realistic for Mut+ strains. Methanol oxidation through AOX consumes large amounts of O2.
To fix in the model: increase **kLa** (better mixing/aeration) or reduce **F_meoh** (slower methanol feed).
In reality this is controlled by cascading agitation speed or switching to O2 enrichment.
""")
    with st.expander("What is the difference between Mut+ and MutS?"):
        st.markdown("""
Both are Pichia pastoris strains with the AOX1 gene disrupted to different degrees.

- **Mut+** (methanol utilisation plus): AOX1 intact, metabolises methanol rapidly, very high OUR, higher μ_max on methanol
- **MutS** (methanol utilisation slow): AOX1 deleted, only AOX2 active, metabolises methanol slowly, low OUR, easier DO control, often higher product titres because cells invest more in protein rather than growth
""")
