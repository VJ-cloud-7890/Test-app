"""
Kinetic models for microbial growth, substrate consumption, and product formation.
"""

import numpy as np


# ─── Growth Kinetics ──────────────────────────────────────────────────────────

def monod(mu_max: float, S: float, Ks: float) -> float:
    """Standard Monod growth kinetics."""
    return mu_max * S / (Ks + S)


def andrews(mu_max: float, S: float, Ks: float, Ki: float) -> float:
    """Andrews (substrate inhibition) kinetics."""
    return mu_max * S / (Ks + S + S**2 / Ki)


def tessier(mu_max: float, S: float, Ks: float) -> float:
    """Tessier kinetics (exponential saturation)."""
    return mu_max * (1 - np.exp(-S / Ks))


def moser(mu_max: float, S: float, Ks: float, n: float = 2.0) -> float:
    """Moser kinetics (generalised Monod with power term)."""
    return mu_max * S**n / (Ks + S**n)


KINETIC_MODELS = {
    "Monod": monod,
    "Andrews (Substrate Inhibition)": andrews,
    "Tessier": tessier,
    "Moser": moser,
}

KINETIC_PARAMS = {
    "Monod":   ["mu_max", "Ks"],
    "Andrews (Substrate Inhibition)": ["mu_max", "Ks", "Ki"],
    "Tessier": ["mu_max", "Ks"],
    "Moser":   ["mu_max", "Ks", "n"],
}

PARAM_DEFAULTS = {
    "mu_max": 0.4,
    "Ks":     0.05,
    "Ki":     5.0,
    "n":      2.0,
}

PARAM_RANGES = {
    "mu_max": (0.01, 2.0),
    "Ks":     (0.001, 5.0),
    "Ki":     (0.1,  50.0),
    "n":      (0.5,  5.0),
}

PARAM_UNITS = {
    "mu_max": "h⁻¹",
    "Ks":     "g/L",
    "Ki":     "g/L",
    "n":      "—",
}


# ─── Product Formation ────────────────────────────────────────────────────────

def luedeking_piret(mu: float, X: float, alpha: float, beta: float) -> float:
    """
    Luedeking-Piret product formation:
        dP/dt = alpha * mu * X  +  beta * X
    Returns the volumetric rate (g/L/h).
    """
    return alpha * mu * X + beta * X
