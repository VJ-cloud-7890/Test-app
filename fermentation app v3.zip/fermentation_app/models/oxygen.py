"""
Dissolved oxygen balance.

DO dynamics:
    dDO/dt = OTR - OUR - D * DO

OTR = kLa * (DO_sat - DO)
OUR = (mu/Yxo_gly)*X  +  mo_gly*X          (on glycerol)
    + (mu/Yxo_meoh)*X +  mo_meoh*X         (on methanol, Mut+ >> MutS)
"""


def OTR(kLa: float, DO_sat: float, DO: float) -> float:
    """Oxygen transfer rate (g/L/h)."""
    return kLa * max(DO_sat - DO, 0.0)


def OUR_glycerol(mu: float, X: float,
                 Yxo_gly: float = 0.5,
                 mo_gly: float = 0.01) -> float:
    """Oxygen uptake rate on glycerol (g O2/L/h)."""
    return (mu / Yxo_gly + mo_gly) * X


def OUR_methanol(mu: float, X: float, q_meoh: float,
                 Yxo_meoh: float = 0.2,
                 mo_meoh: float = 0.05,
                 mut_plus: bool = True) -> float:
    """
    Oxygen uptake rate on methanol.
    Mut+ has much higher OUR due to AOX-driven oxidation.
    """
    base = (mu / Yxo_meoh + mo_meoh) * X
    # Mut+ additional OUR from methanol oxidation
    meoh_factor = 1.5 if mut_plus else 0.3
    return base + meoh_factor * q_meoh * X


def do_balance(kLa, DO_sat, DO, mu, X,
               on_glycerol=True, on_methanol=False,
               q_meoh=0.0, mut_plus=True, D=0.0,
               Yxo_gly=0.5, mo_gly=0.01,
               Yxo_meoh=0.2, mo_meoh=0.05) -> float:
    """
    Net DO rate of change (g/L/h or % sat/h depending on units used).
    """
    otr = OTR(kLa, DO_sat, DO)
    our = 0.0
    if on_glycerol:
        our += OUR_glycerol(mu, X, Yxo_gly, mo_gly)
    if on_methanol:
        our += OUR_methanol(mu, X, q_meoh, Yxo_meoh, mo_meoh, mut_plus)
    return otr - our - D * DO
