"""
Biological constraint enforcer.
Every rate passes through here before entering the ODE.
"""
import numpy as np


def clip_positive(val):
    return max(val, 0.0)


def enforce_substrate(rate, S, threshold=1e-6):
    """Zero out any rate if substrate is effectively depleted."""
    return rate if S > threshold else 0.0


def enforce_do(rate, DO, DO_crit):
    """Zero out growth/production if DO is below critical threshold."""
    return rate if DO > DO_crit else 0.0


def enforce_product_formation(qp, MeOH=None, Gly=None,
                               meoh_only=False, Gly_rep=None,
                               meoh_threshold=0.01):
    """
    Product formation constraints:
    - Zero if methanol-only mode and no methanol present
    - Zero if glycerol repression threshold exceeded
    """
    if meoh_only and (MeOH is None or MeOH < meoh_threshold):
        return 0.0
    if Gly_rep is not None and Gly is not None and Gly > Gly_rep:
        return 0.0
    return clip_positive(qp)


def enforce_feed(F, t, t_start, t_end):
    """Feed is only active between t_start and t_end."""
    return F if t_start <= t <= t_end else 0.0


def apply_product_inhibition(mu, P, Ki_P):
    """Reduce growth rate due to product accumulation."""
    if Ki_P <= 0:
        return mu
    return mu * (1.0 - min(P / Ki_P, 1.0))
